-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2024 at 06:24 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `c_pass` varchar(100) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `sname`, `username`, `email`, `number`, `password`, `c_pass`, `time`) VALUES
(1, '', '', ' ', '', ' ', '', '2024-08-10 22:15:23'),
(2, 'Ashraful Khan siyam', 'siyam', ' dj56832190@gmail.com', '01783867763', ' 12345', '12345', '2024-08-10 22:15:58'),
(3, '', '', ' ', '', ' ', '', '2024-08-10 22:16:20'),
(4, 'Ashraful Khan siyam', 'siyam', ' dj56832190@gmail.com', '01783867763', ' 12345', '12345', '2024-08-10 22:16:29'),
(5, '', '', ' ', '', ' ', '', '2024-08-10 22:16:31'),
(6, '', '', ' ', '', ' ', '', '2024-08-10 22:17:19'),
(7, 'Ashraful Khan siyam', 'ashrafulkhansiyam', ' dj56832190@gmail.com', '01783867763', ' 123', '123', '2024-08-10 22:17:27'),
(8, 'Ashraful Khan siyam', 'ashrafulkhansiyam', ' dj56832190@gmail.com', '01783867763', ' 123', '123', '2024-08-10 22:19:21'),
(9, 'Ashraful Khan siyam', 'ashrafulkhansiyam', ' dj56832190@gmail.com', '01783867763', ' 12345', '12345', '2024-08-10 22:19:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
